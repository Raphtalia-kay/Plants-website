import React from 'react'
import PlantDetail from '../components/PlantDetail'

const PlantDetialPage = () => {
  return (
    <div>
      <PlantDetail/>
    </div>
  )
}

export default PlantDetialPage
