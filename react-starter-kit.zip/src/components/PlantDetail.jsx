import React from 'react'
import { useParams } from 'react-router-dom'

const PlantDetail = () => {
//     const {id} = useParams();
//     const [ plants,setPlants] = useState([]);
    
    
//   return (
//     <div>
//       <div className="">
//         kkkkk
//       </div>
//     </div>
//   )
}

export default PlantDetail
