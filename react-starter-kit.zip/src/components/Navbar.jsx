import { Badge, FavoriteBorderRounded, ShoppingCartOutlined } from "@mui/icons-material";
import React from "react";
import {BiSearchAlt2} from "react-icons/bi";
import {MdOutlinePeopleAlt} from "react-icons/md";

const Navbar = () => {
  return (
    <>
      <div className=" navbar h-[60px] shadow-md relative z-10 flex  items-center border ">
        <div className="flex flex-1 justify-center">
          <h1 className="text-2xl font-bold">Plantie</h1>
        </div>

        {/* search div */}

        <div className=" flex flex-1 items-center gap-2  ">
          <div className=" cursor-pointer text-[16px] ">En</div>

          <div className="flex border-[2px] border-solid border-lightgrey rounded-md items-center focus-within:border-[#071a52] transition-all">

            <input
              type="text"
              placeholder="Search..."
              className="outline-none"
            />
          <BiSearchAlt2 className="text-xl "/>
            
          </div>
        </div>
        <div className="flex flex-1 justify-end items-center ">
          <div className="px-2 text-[25px]">
            <MdOutlinePeopleAlt/>
          </div>
          <div className="px-2">
            <FavoriteBorderRounded/> 
          </div>
          <div className="px-2 text-[14px] cursor-pointer ml-[10px]">
          <Badge badgecontent={0} color="secondary">
          <ShoppingCartOutlined/>
          </Badge>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
