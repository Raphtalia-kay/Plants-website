import React from 'react'

const Cate = ({image,name}) => {
  return (
    <div>
      <div className="border-2 shadow-md rounded-lg relative">
        <img src={image} className='w-[400px] h-[300px] object-contain hover:opacity-50 ease-in duration-200' alt="" />
        <div className="flex w-[100%] h-[100%] left-0  flex-col justify-center items-center absolute top-0 ">
            <p className='text-[25px] text-[#4CAF5f] font-semibold'>{name}</p>
                <button className="btn">See More</button>
        </div>
      </div>
    </div>
  )
}

export default Cate
