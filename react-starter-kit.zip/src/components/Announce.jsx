import React, { useState } from "react";
import { RxCross2 } from "react-icons/rx";

const Announce = () => {
    const [AnnounceStyle,setAnnounceStyle] = useState('all flex  px-30  bg-primary justify-center items-center text-white text-[12px] ')
    const handleClose = ()=>{
        setAnnounceStyle(AnnounceStyle + " hidden");
    }
  return (
    <div>

      <div className={AnnounceStyle}>
      <div className=" first">
            <h4>start a free trial and enjoy 3 months of Plantie for $1/month on select plans.<span className=" text-[15px] underline font-bold">Sign up now</span></h4>
        </div>
        <div className="second">
        <RxCross2 onClick={handleClose} className="cursor-pointer text-left text-2xl" />
        </div>
      </div>

     
    </div>
  );
};

export default Announce;
