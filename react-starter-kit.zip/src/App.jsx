import React from 'react'
import "./App.css"
import Home from './page/Home'
import { Route, Routes } from 'react-router-dom'
import PlantDetialPage from './page/PlantDetialPage'

const App = () => {
  return (
    <>
     <Routes>
      <Route path="/" element={<Home/>}></Route>
      {/* <Route path={`/plantdetail/${id}`} element={<PlantDetialPage/>}></Route> */}
     </Routes>
    </>
  )
}

export default App